import argparse
import asyncio
import json
import os
import random
import glob
import yaml
import copy
import re

import pandas as pd

from transformers.trainer_utils import set_seed
import numpy as np
from tqdm import tqdm
from tqdm.asyncio import tqdm_asyncio
from langchain.chat_models import ChatOpenAI
from langchain.llms import OpenAIChat, OpenAI
from langchain.schema import AIMessage, HumanMessage, SystemMessage

from datasets import load_dataset, concatenate_datasets
import openai
from evaluate import load

from models.model import OpenAIModel, LocalModel
from prompters import AlpacaPrompter, GPTPrompter, VLLMGPTPrompter, PromptStyle

os.environ["HF_ALLOW_CODE_EVAL"] = "1"
# openai.api_key = "EMPTY"
# openai.api_base = "http://localhost:8000/v1"
set_seed(42)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", type=str, default=None)
    parser.add_argument("--model_port", type=int, default=None)
    parser.add_argument("--model_type", type=str, default="gpt", choices=["local", "gpt"])
    parser.add_argument("--data_name", type=str, default="DLI-Lab/med_critic1_train_1000")
    parser.add_argument("--prompt_path", type=str, default="./prompt/prompt.yaml")
    parser.add_argument("--prompt_key", type=str, default="base")
    parser.add_argument("--n", type=int, default=None)
    parser.add_argument("--split", type=str, default="train", choices=["train", "valid", "test"])
    parser.add_argument("--num_try", type=int, default=1, help="number of samples to generate")
    parser.add_argument("--save_dir", type=str, default="./results")
    parser.add_argument("--limit", type=int, default=10)
    return parser.parse_args()

def load_data(data_name, split=None):
    with open('generation_results/step_1/all.json','r') as f:
        data = json.load(f)
    print("=========== dataset statistics ===========")
    print(len(data))
    print("==========================================")
    return data

def load_vllm_data(data_name, split=None):
    jpeg_folder_path = "/data/hssd-hab/objects_img/google/cropped_bg_jpeg"
    jpeg_files = glob.glob(f"{jpeg_folder_path}/*.jpg")
    
    category_file_path = "/data/hssd-hab/metadata/object_categories_filtered.csv"
    category_df = pd.read_csv(category_file_path)
    category_dict = category_df.set_index('id').to_dict()['clean_category']
    
    data = [
        {
        "id": file.split(".")[0].split("/")[-1], 
        "image": f"https://raw.githubusercontent.com/dongwxxkchoi/object_imgs/master/google/cropped_bg_jpeg/{file.split('.')[0].split('/')[-1]}.jpg", 
        "name": file.split(".")[0].split("/")[-1],
        "category": category_dict.get(file.split(".")[0].split("/")[-1], "Unknown")
        } 
            for file in jpeg_files
        ]
    
    print("=========== dataset statistics ===========")
    print(len(data))
    print("==========================================")
    return data


def prepare_model_input(prompter, input_data, input_img=None):
    get_input = input_data["input"]
    get_instruction = input_data["instruction"]
    get_output = ""
    model_input = prompter.build_prompt(instruction=get_instruction, input=get_input, output=get_output)
    return model_input

def prepare_gpt_model_input(prompter, input_data):
    model_input = prompter.build_prompt(input_data)
    return model_input

def load_and_prepare_data(args):
    if args.prompt_key == 'captioning' or args.prompt_key == 'captioning_google':
        dataset = load_vllm_data(args.data_name, args.split)
        if args.model_type == "gpt":
            prompter = VLLMGPTPrompter(args.prompt_path, args.prompt_key)
    else:
        dataset = load_data(args.data_name, args.split)
        if args.model_type == "gpt":
            prompter = GPTPrompter(args.prompt_path, args.prompt_key)
        else:
            prompter = AlpacaPrompter()
            
    all_model_inputs = []
    print("### load and prepare data")
    for data in tqdm(dataset):
        if args.model_type == "gpt":
            model_input = prepare_gpt_model_input(prompter, data)
        else:
            model_input = prepare_model_input(prompter, data)
        all_model_inputs.append([model_input, data])
    return all_model_inputs


async def async_generate(llm, model_input, prompt_key, is_multiple=False):
    while True:
        try:
            if is_multiple:
                if prompt_key == "captioning":
                    response = await llm.multiple_generate(model_input[0], model_input[1]['image'], image=True)
                else:
                    response = await llm.multiple_generate(model_input[0])
            else:
                if prompt_key == "captioning":
                    response = await llm.single_generate(model_input[0], model_input[1]['image'], image=True)
                else:
                    response = await llm.single_generate(model_input[0])
            break
        except Exception as e:
            print(f"Exception occurred: {e}")
            return None
    if prompt_key == "captioning":
        result = {
            "prediction": response['prediction'],
            "id": model_input[1]["id"], 
            "category": model_input[1]["category"]
        }
    else:
        result = {
            "prediction": response['prediction'],
            "model_input": model_input[0], # model_input
            **model_input[1], # data
        }
    return result


async def generate_concurrently(all_model_input, stop, args):
    if args.model_type == "local":
        llm = LocalModel(
            model_name=args.model_name,
            openai_api_base=f"http://localhost:{args.model_port}/v1",
            openai_api_key="EMPTY",
            max_tokens=128,
            top_p=0.95,
            temperature=0.5,
            frequency_penalty=0.4,
            stop=stop,
            n=args.n
        )
    elif args.model_type == "gpt":
        llm = OpenAIModel(
            model_name=args.model_name,
            max_tokens=1024,
            top_p=0.95,
            temperature=1.0,
            frequency_penalty=0.0,
            stop=stop,
            n=args.n
            )
    tasks = [
        async_generate(llm, model_input, args.prompt_key, args.n) for i, model_input in enumerate(all_model_input)
    ]
    return await tqdm_asyncio.gather(*tasks)

async def main(args):
    all_model_inputs = load_and_prepare_data(args)
    for i in range(args.num_try):
        save_path = os.path.join(args.save_dir, f"{i+1}_sample")
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        all_results = await generate_concurrently(all_model_inputs, "\n", args)  # generate code
        with open(os.path.join(save_path, "seed_try.json"), "w", encoding="UTF-8") as f:
            json.dump(all_results, f, indent=4)



if __name__ == "__main__":
    args = parse_args()
    asyncio.run(main(args))
    print("Done!")
