import json
import openai
import pandas as pd
from sklearn.cluster import KMeans
from collections import defaultdict
from tqdm import tqdm

# ----------------------------------------------------
# 1. 데이터 불러오기
# ----------------------------------------------------
with open('category_handle.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# ----------------------------------------------------
# 2. 캡션 정보만 추출하여 리스트/데이터프레임화
# ----------------------------------------------------
all_captions = []

for category, items_list in data.items():
    for item in items_list:
        for sub_item in item:
            row = {
                "id": sub_item["id"],
                "caption": sub_item["caption"],
                "source": sub_item["source"],
                "category": category
            }
            all_captions.append(row)

df = pd.DataFrame(all_captions)
print("전체 데이터프레임 형태 확인:")
print(df.head())

# ----------------------------------------------------
# 3. OpenAI Embedding 호출 설정 (API 키 설정 필요)
# ----------------------------------------------------
client = openai.OpenAI(api_key="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")  # API 키 설정

# ----------------------------------------------------
# 4. 카테고리별 클러스터링 진행
# ----------------------------------------------------
num_clusters = 2  # 클러스터 개수 (필요하면 조정)

# 각 카테고리별 결과 저장용 딕셔너리
category_cluster_results = defaultdict(list)

for _, category in tqdm(enumerate(df["category"].unique())):
    print(f"\n==== 카테고리: {category} ====")

    # 특정 카테고리의 데이터 필터링
    category_df = df[df["category"] == category].copy()

    if len(category_df) < num_clusters:
        print(f"[경고] 카테고리 '{category}'의 샘플 수({len(category_df)})가 클러스터 개수({num_clusters})보다 적어 클러스터링을 수행할 수 없습니다. 건너뜁니다.")
        continue

    # OpenAI Embedding API로 각 캡션 임베딩 얻기
    embeddings = []
    for caption in category_df["caption"]:
        response = client.embeddings.create(
            model="text-embedding-ada-002",
            input=caption
        )
        embedding_vector = response.data[0].embedding
        embeddings.append(embedding_vector)

    # 임베딩 벡터 저장
    category_df["embedding"] = embeddings

    # K-Means 클러스터링 실행
    kmeans = KMeans(n_clusters=num_clusters, random_state=42, n_init=10)
    kmeans.fit(embeddings)

    # 결과 클러스터 저장
    category_df["cluster"] = kmeans.labels_
    
    # 결과 저장
    category_cluster_results[category] = category_df

    # ----------------------------------------------------
    # 5. 클러스터링 결과 출력
    # ----------------------------------------------------
    print("\n[클러스터링 결과]")
    print(category_df[["id", "caption", "cluster"]].head(20))

    # 클러스터별로 출력
    for c in range(num_clusters):
        cluster_df = category_df[category_df["cluster"] == c]
        print(f"\n### Cluster {c} (총 {len(cluster_df)}개)")
        for idx, row in cluster_df.iterrows():
            print(f" - {row['caption']} (id: {row['id']})")

# ----------------------------------------------------
# 6. 전체 클러스터링 결과를 CSV로 저장
# ----------------------------------------------------
final_df = pd.concat(category_cluster_results.values(), ignore_index=True)
final_df.to_csv("category_cluster_results.csv", index=False)
print("\n[완료] 카테고리별 클러스터링 결과를 category_cluster_results.csv 파일로 저장했습니다.")