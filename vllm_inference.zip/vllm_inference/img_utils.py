from PIL import Image
import glob
from tqdm import tqdm
import base64
import io
import os

def crop_image_center(image_path: str):
    image = Image.open(image_path)

    width, height = image.size

    left = width // 3 
    right = 2 * (width // 3) 
    top = 0  
    bottom = height  

    center_image = image.crop((left, top, right, bottom))

    center_image_path = "/data/hssd-hab/objects_cropped_img/" + image_path.split("/")[-1]
    center_image.save(center_image_path)


def encode_image_to_base64(image_path: str) -> str:
    if not image_path:
        return None
    with open(image_path, "rb") as f:
        image_data = f.read()
    return "data:image/jpeg;base64," + base64.b64encode(image_data).decode("utf-8")


def compress_and_encode_image_to_base64(image_path: str, max_size=(512, 512), quality=85) -> str:
    """
    - max_size: (width, height) (default: 512x512)
    - quality: JPEG compression quality (0~100, default: 85)
    """
    if not image_path:
        return None
    
    with Image.open(image_path) as img:
        img = img.convert("RGB")  
        img.thumbnail(max_size)   
        
        buffer = io.BytesIO()
        img.save(buffer, format="JPEG", quality=quality)
        buffer.seek(0)

        encoded_str = base64.b64encode(buffer.getvalue()).decode("utf-8")
    
    return "data:image/jpeg;base64," + encoded_str


# def compress_and_save_image(image_path: str, output_path: str, max_size=(512, 512), quality=85):
#     """
#     - image_path: 원본 이미지 경로
#     - output_path: 저장할 파일 경로 (예: "output.jpg")
#     - max_size: (width, height) (기본: 512x512)
#     - quality: JPEG 압축 품질 (0~100, 기본: 85)
#     """
#     print(image_path)
#     print(output_path)
#     if not os.path.exists(image_path):
#         print(f"파일을 찾을 수 없습니다: {image_path}")
#         return
    
#     with Image.open(image_path) as img:
#         img = img.convert("RGB")  # PNG의 투명도 제거 (JPEG는 투명도 지원 X)
#         img.thumbnail(max_size)   # 크기 조정
        
#         # JPEG로 저장 (압축 적용)
#         img.save(output_path, format="JPEG", quality=quality)
#         print(f"✅ 저장 완료: {output_path}")


# input_path = "/data/hssd-hab/objects_cropped_img/"
# img_list = glob.glob(f"{input_path}/*.png")
# for img in tqdm(img_list):
#     compress_and_save_image(img, "test.jpg")
#     break
#     print(f"✅ 저장 완료: {file}")