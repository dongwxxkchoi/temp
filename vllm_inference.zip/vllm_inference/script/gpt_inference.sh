python inference.py \
--model_name "gpt-4o" \
--model_port "8000" \
--prompt_key "routine" \
--model_type "gpt" \
--save_dir "./new_results/routine"
