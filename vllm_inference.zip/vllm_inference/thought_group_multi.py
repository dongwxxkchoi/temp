import asyncio
import base64
from langsmith import Client
from langchain_openai import ChatOpenAI
from tqdm import tqdm
from datetime import datetime, timedelta
import time
import json
import logging
import os
import sys

from concurrent.futures import ThreadPoolExecutor, as_completed

from models import OPENAI_MODELS

# 로그 설정
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

API_MAX_RETRY = 20
API_RETRY_SLEEP = 20


def update_progress_bar(completed, total, start_time):
    # Calculate elapsed time and estimated total time
    elapsed_time = time.time() - start_time
    average_time_per_task = elapsed_time / completed if completed > 0 else 0
    estimated_total_time = average_time_per_task * total
    remaining_time = estimated_total_time - elapsed_time

    # Format times as HH:MM:SS
    elapsed_str = str(timedelta(seconds=int(elapsed_time)))
    remaining_str = str(timedelta(seconds=int(remaining_time)))
    total_str = str(timedelta(seconds=int(estimated_total_time)))

    # Calculate progress
    progress = int(50 * completed / total)  # 50 chars width for progress bar
    sys.stdout.write("\r[{}{}] {}/{} - Elapsed: {}, Remaining: {}, Total: {}\n".format(
        "#" * progress, "." * (50 - progress), completed, total, elapsed_str, remaining_str, total_str))
    sys.stdout.flush()


def get_reason_action_history(reason_list, action_list):
    history = ""
    if len(action_list) == 0:
        return history
    for idx, (reason, action) in enumerate(zip(reason_list, action_list)):
        history += f"REASON {idx+1}: {reason}\nACTION {idx+1}: {action}\n"
    return history


def process_single_data(data, prompt, llm):
    if data["inputs"]["action_type"] == "bid":
        if data["inputs"]["image2"]:
            model_input = prompt["bid"].first.invoke(data['inputs'])
        else:
            model_input = prompt["bid_final_state"].first.invoke(data['inputs'])
    else:
        if data["inputs"]["image2"]:
            if data["inputs"]["image_cursor"]:
                model_input = prompt["coord_mouse"].first.invoke(data['inputs'])
            else:
                model_input = prompt["coord"].first.invoke(data['inputs'])
        else:
            model_input = prompt["coord_final_state"].first.invoke(data['inputs'])

    # Retry logic in case of API error
    for _ in range(API_MAX_RETRY):
        try:
            result = llm.invoke(model_input)
            break
        except Exception as e:
            # Handle API error here, e.g. retry or log
            print(f"OpenAI API returned an API Error: {e}")
            print(f"Error data: {data['inputs']['action_history']}")
            time.sleep(API_RETRY_SLEEP)

    cost = 0.7 * result.usage_metadata['total_tokens'] / 1000000

    return data, result, cost


def process_task_group(task_idx, group, prompt, llm, start_time, total_tasks, progress_data):
    """
    Process the steps for a single task_idx sequentially.
    Return the partial results and total cost from this group.
    """
    reason_history = []
    action_history = []
    group_results = []
    group_cost = 0.0
    existing_data = []

    # Sort by step_idx (already sorted outside, but let's be sure)
    group.sort(key=lambda x: x['inputs']['step_idx'])

    for data in group:
        try:
            # Process action reason history
            data["action_history_list"] = get_reason_action_history(reason_history, action_history)

            # Get result
            data, result, cost = process_single_data(data, prompt, llm)
            group_cost += cost

            # Extract reason from the result
            reason = result.content.split("ACTION")[0].strip().replace("\n", "")
            group_results.append([data, reason])

            # Update reason/action histories
            reason_history.append(reason)
            action_history.append(data['inputs']['action'])

            # # Save partial results in existing_data (tmp save)
            # tmp_results = {
            #     "instruction": data['inputs']['instruction'],
            #     "action_history": data['inputs']['action_history'],
            #     "text_somtree": data['inputs']['text_somtree'],
            #     "action": data['inputs']['action'],
            #     "thought": reason,
            #     "idx": data['idx']
            # }
            # existing_data.append(tmp_results)

        except Exception as e:
            print(f"Error processing data idx={data['idx']}: {e}")

        # Update progress data (thread-safe with a lock)
        with progress_data["lock"]:
            progress_data["completed"] += 1
            completed_tasks = progress_data["completed"]
            update_progress_bar(completed_tasks, total_tasks, start_time)

    # # Sort existing_data by idx and save partial
    # existing_data = sorted(existing_data, key=lambda x: x["idx"])
    # with open("tmp_results_task_{}.json".format(task_idx), "w", encoding="utf-8") as f:
    #     json.dump(existing_data, f, indent=4, ensure_ascii=False)

    return group_results, group_cost


def main(data_list, prompt, llm, max_workers=5):
    """
    data_list: all data across all task_idxs
    prompt: dictionary of prompts
    llm: your LLM
    max_workers: number of parallel threads
    """
    # Group by task_idx
    task_idx_groups = {}
    for data in data_list:
        t_idx = data['inputs']['task_idx']
        if t_idx not in task_idx_groups:
            task_idx_groups[t_idx] = []
        task_idx_groups[t_idx].append(data)

    total_tasks = sum(len(group) for group in task_idx_groups.values())

    # We want to process each group in parallel, 
    # but steps within a group must remain sequential.
    # We'll use a ThreadPoolExecutor for concurrency across task_idx groups.
    results_all = []
    total_cost = 0.0
    start_time = time.time()

    # We'll store partial concurrency progress info in a dict
    # This dictionary is shared by all threads for the progress bar
    # We store a lock for thread-safe updates
    from threading import Lock
    progress_data = {"completed": 0, "lock": Lock()}

    # Convert group dict to list to keep consistent iteration
    task_group_items = list(task_idx_groups.items())

    # Sort by task_idx to keep a stable order (optional):
    task_group_items.sort(key=lambda x: x[0])

    # Submit tasks in parallel
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_task_idx = {}
        for task_idx, group in task_group_items:
            future = executor.submit(process_task_group,
                                     task_idx,
                                     group,
                                     prompt,
                                     llm,
                                     start_time,
                                     total_tasks,
                                     progress_data)
            future_to_task_idx[future] = task_idx

        # Collect results
        for future in as_completed(future_to_task_idx):
            task_idx = future_to_task_idx[future]
            try:
                group_results, group_cost = future.result()
                total_cost += group_cost
                # Append to results_all
                results_all.extend(group_results)
            except Exception as exc:
                print(f"Task group {task_idx} generated an exception: {exc}")

    print("\nAll tasks finished.")
    print(f"Total cost: {total_cost:.6f}")
    return results_all


def process_results(results, save_path):
    final_results = []
    only_thought = []
    for result in results:
        final_results.append({
            "instruction": result[0]['inputs']['instruction'],
            "website_name": result[0]['inputs']['website_name'],
            "current_url": result[0]['inputs']['current_url'],
            "action_history": result[0]['inputs']['action_history'],
            "thought_history": None,
            "text_axtree": result[0]['inputs']['text_axtree'],
            "text_somtree": result[0]['inputs']['text_somtree'],
            "current_image": result[0]['inputs']['image_path'],
            "current_image_cursor": result[0]['inputs']['image_cursor_path'],
            "thought": result[1],
            "action": result[0]['inputs']['action'],
            "action_type": result[0]['inputs']['action_type'],
            "task_idx": result[0]['inputs']['task_idx'],
            "idx": result[0]['idx']
        })
        only_thought.append({
            "instruction": result[0]['inputs']['instruction'],
            "action_history": result[0]['inputs']['action_history'],
            "text_axtree": result[0]['inputs']['text_axtree'],
            "text_somtree": result[0]['inputs']['text_somtree'],
            "action": result[0]['inputs']['action'],
            "thought": result[1],
            "idx": result[0]['idx']
        })

    # Sort by idx
    only_thought.sort(key=lambda x: x["idx"])
    final_results.sort(key=lambda x: x["idx"])

    # Rebuild "thought_history" for each instruction group
    tmp_instruction = ""
    problem_start_idx = -1
    for idx, fr in enumerate(final_results):
        if tmp_instruction != fr["instruction"]:
            tmp_instruction = fr["instruction"]
            problem_start_idx = idx
        # Each final_result stores the thought history from its “group start” to (idx-1)
        final_results[idx]["thought_history"] = [final_results[i]["thought"] 
                                                 for i in range(problem_start_idx, idx)]

    # Save results as JSON
    os.makedirs(save_path, exist_ok=True)
    with open(os.path.join(save_path, "only_thought.json"), "w") as f:
        json.dump(only_thought, f, indent=4)
    with open(os.path.join(save_path, "final_results.json"), "w") as f:
        json.dump(final_results, f, indent=4)


def encode_image_to_base64(image_path: str) -> str:
    """
    이미지 파일을 base64 문자열로 변환하는 간단한 함수
    """
    if not image_path:
        return None
    with open(image_path, "rb") as f:
        image_data = f.read()
    return "data:image/png;base64," + base64.b64encode(image_data).decode("utf-8")


def setup(config):
    LANGSMITH_API_KEY = config["LANGSMITH_API_KEY"]
    if config["model_args"]["model_name"] in OPENAI_MODELS:
        MODEL_API_KEY = config["OPENAI_API_KEY"]
    else:
        MODEL_API_KEY = None

    prompt_path = config["prompt_path"]
    save_path = config["save_path"]
    model_name = config["model_args"]["model_name"]
    base_url = config["model_args"]["base_url"]
    temperature = config["model_args"]["temperature"]

    os.makedirs(save_path, exist_ok=True)
    client = Client(api_key=LANGSMITH_API_KEY)
    prompt = {
        "bid": client.pull_prompt(prompt_path["bid"], include_model=True),
        "bid_final_state": client.pull_prompt(prompt_path["bid_final_state"], include_model=True),
        "coord": client.pull_prompt(prompt_path["coord"], include_model=True),
        "coord_mouse": client.pull_prompt(prompt_path["coord_mouse"], include_model=True),
        "coord_final_state": client.pull_prompt(prompt_path["coord_final_state"], include_model=True)
    }

    llm = ChatOpenAI(model=model_name, 
                     base_url=base_url, 
                     api_key=MODEL_API_KEY, 
                     temperature=temperature)

    data_list = []
    idx = 0
    with open(config["dataset_path"], "r") as f:
        for line in f:
            data = json.loads(line)
            data["idx"] = idx
            # Depending on action_type and your logic, build data['inputs']['image'] / image2 as needed
            if data["inputs"]["action_type"] == "bid":
                data["inputs"]["image"] = encode_image_to_base64(data["inputs"]["image_path"])
                data["inputs"]["image2"] = encode_image_to_base64(data["inputs"]["image2_path"])
            else:
                # coord type
                data["inputs"]["image"] = encode_image_to_base64(data["inputs"]["image_path"])
                if data["inputs"]["image_cursor_path"]:
                    data["inputs"]["image_cursor"] = encode_image_to_base64(data["inputs"]["image_cursor_path"])
                else:
                    data["inputs"]["image_cursor"] = None

                data["inputs"]["image2"] = encode_image_to_base64(data["inputs"]["image2_path"])

            data_list.append(data)
            idx += 1

    start_idx = config["index_info"]["start_idx"]
    num_samples = config["index_info"]["num_samples"]
    if start_idx is not None:
        data_list = data_list[start_idx:]
    if num_samples is not None:
        data_list = data_list[:num_samples]

    return data_list, prompt, llm

if __name__ == "__main__":
    config = {
        "LANGSMITH_API_KEY": "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",
        "OPENAI_API_KEY": "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",
        "OPENROUTER_API_KEY": "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",
        "prompt_path" : {
            "bid": "webrm/web_thought_generate",
            "bid_final_state": "webrm/web_thought_generate_final_state",
            "coord": "webrm/web_thought_generate_coord",
            "coord_mouse": "webrm/web_thought_generate_coord_mouse",
            "coord_final_state": "webrm/web_thought_generate_coord_final_state"
        },
        "dataset_path": "/home/dongjin/seonghwan/RM_web_agent/annotation/base_dataset/thought_coord/inference_dataset.jsonl",
        "save_path": "/home/dongjin/seonghwan/RM_web_agent/annotation/results/thought_group_coord",
        "index_info": {
            "start_idx": None,   # default: None
            "num_samples": None # default: None
        },
        "model_args": {
            "model_name": "Qwen/Qwen2.5-VL-72B-Instruct-AWQ",   # qwen/qwen2.5-vl-72b-instruct, gpt-4o-mini, gpt-4o
            "temperature": 0.5,
        }
    }
    if config["model_args"]["model_name"] in OPENAI_MODELS:
        os.environ["OPENAI_API_KEY"] = config["OPENAI_API_KEY"]
        config["model_args"]["base_url"] = "https://api.openai.com/v1"
    else:
        # os.environ["OPENAI_API_KEY"] = config["OPENROUTER_API_KEY"]
        # config["model_args"]["base_url"] = "https://openrouter.ai/api/v1"
        os.environ["OPENAI_API_KEY"] = config["OPENAI_API_KEY"]
        config["model_args"]["base_url"] = "http://165.132.46.149:8080/v1"

    data_list, prompt, llm = setup(config)
    logger.info(f"Current time: {datetime.now()}")
    logger.info(f"Processing {len(data_list)} data")
    logger.info("Inference data")
    # results = asyncio.run(main(data_list, prompt, llm))
    results = main(data_list, prompt, llm)
    logger.info("Process results")
    process_results(results, config["save_path"])
    logger.info("Done")