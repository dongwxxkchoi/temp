import json
from collections import defaultdict, Counter
from typing import List, Dict, Callable
import random

from utils import output_as_dataset, renew_episode_info, add_metadata, extract_original_info, add_stage_2
import pandas as pd

def check_used_object(eval: Dict, df: pd.DataFrame, keys: list):
    if eval['function_name'] in ["is_on_top", "is_inside", "is_in_room"]:
        handle = eval['args']['object_handles'][0] # 여기에 list인 경우 category가 같은 경우이므로
        id = handle.split(":")[0][:-1]
        target_df = df[df['id'] == id][keys]
        if not target_df.empty:
            if len(keys) == 1:
                target = target_df.iloc[0][keys[0]]  # 단일 값 반환
            else:
                target = target_df.iloc[0].tolist()  # 여러 개 값 리스트로 반환
            return [target]
        else:
            return []
    
    elif eval['function_name'] in ["is_next_to"]:
        #TODO: entity_a, entity_b는 receptacle이 있는 경우도 있음. 따라서, 이를 해결하기 위한 로직 필요
        used_targets = []
        
        handle_a = eval['args']['entity_handles_a'][0] # 여기에 list인 경우 category가 같은 경우이므로
        handle_b = eval['args']['entity_handles_b'][0] # 여기에 list인 경우 category가 같은 경우이므로
        id_a = handle_a.split(":")[0][:-1]
        id_b = handle_b.split(":")[0][:-1]
        target_a_df = df[df['id'] == id_a][keys]
        target_b_df = df[df['id'] == id_b][keys]
        if not target_a_df.empty:
            if len(keys) == 1:
                used_targets.append(target_a_df.iloc[0][keys[0]])  # 단일 값
            else:
                used_targets.append(target_a_df.iloc[0].tolist())  # 여러 개 값 리스트

        if not target_b_df.empty:
            if len(keys) == 1:
                used_targets.append(target_b_df.iloc[0][keys[0]])  # 단일 값
            else:
                used_targets.append(target_b_df.iloc[0].tolist())  # 여러 개 값 리스트
        
        return used_targets
    else:
        return []

def edit_path(data_path: str):
    return "data" + data_path.split('data')[-1]


class TaskPipeline:
    def __init__(self, 
                 data_path: str,
                 tuned_instructions: List[Dict], 
                 dataset: Dict, 
                 distractor_sampling_fn: Callable, 
                 object_category_df: pd.DataFrame,
                 category_cluster_df: pd.DataFrame
                 ):  
        """
        :param dataset: 원본 instruction 파일 리스트 (List of Dict) /data/datasets/partnr_episodes/v0_0/train_2k.json
        :param tuned_instructions: 튜닝된 instruction 리스트 (List of Dict)
        :param distractor_sampling_fn: 데이터 샘플링 함수
        """
        self.data_path = edit_path(data_path)
        
        self.dataset = dataset # raw datasets
        self.scenes = self.group_by_scene() # datas grouped by scenes
        
        ## About both
        self.tuned_instructions = tuned_instructions # augmented instructions
        
        ## About object semantics
        self.distractor_sampling_fn = distractor_sampling_fn # sampling function (아직 미정) # => (그냥 예시 속 데이터 가져오기)
        self.object_category_df = object_category_df # object의 category
        self.category_cluster_df = category_cluster_df # object의 caption과 cluster
        
        self.final_dataset = {} # scene_id: [dataset_1, dataset_2, ...]


    def group_by_scene(self) -> Dict[str, List[Dict]]:
        """
        Scene ID 기준으로 에피소드 그룹화
        :return: scene_id를 key로 하는 episode dictionary ex. 203817140: [{}, {}]
        """
        scene_dict = defaultdict(list)
        for episode in self.dataset:
            scene_id = episode.get("scene_id", "unknown_scene")
            episode["used"] = False # 나중에 기록 용도
            scene_dict[scene_id].append(episode)
        
        return scene_dict

    def preprocess_instruction_set(self):
        """
        Instruction set을 전처리하여 적절한 형태로 변환
        """
        object_df = pd.DataFrame(self.tuned_instructions["object"])
        routine_df = pd.DataFrame(self.tuned_instructions["routine"])
        preference_df = pd.DataFrame(self.tuned_instructions["preference"])

        return object_df, routine_df, preference_df

    def create_dataset(self):
        for scene_id, episodes in self.scenes.items():
            if scene_id == "102817140":
                self.final_dataset[scene_id] = self.create_dataset_per_scene(scene_id)
                break
    
    def create_dataset_per_scene(self, scene_id: str):
        datasets = self.create_dataset_for_object(scene_id)
        # datasets = self.create_dataset_for_user_pattern(scene_id, datasets)
        
        return datasets
    
    def check_objects_can_sampled(self, used_object_categories):
        for category in used_object_categories:
            if category not in self.category_cluster_df['category'].values:
                return False
        
        return True
    
    def create_dataset_for_object(self, scene_id: str) -> List[Dict]:
        """
        sampling per scene of original datasets.
        dataset 당 5개의 episode 포함하도록함.
        최종 final_dataset의 양이 가지고 있는 episode의 반이 넘어가면 멈춤.
        -> 나머지 반을 user pattern으로 활용함
        """
        import copy
        import itertools
        
        datasets = []
        episodes = self.scenes[scene_id]
        
        while len(list(itertools.chain(*datasets))) + 10 < len(episodes) / 2:
            sampled_episodes = []
            total_used_object_categories = []
            for i, episode in enumerate(self.scenes[scene_id]):
                used_object_categories = self.extract_categories_from_episode(episode)
                # if any(item in total_used_object_categories for item in used_object_categories):
                    # continue
                if self.scenes[scene_id][i]['used']:
                    continue
                elif not self.check_objects_can_sampled(used_object_categories):
                    continue
                else:
                    total_used_object_categories.extend(used_object_categories)
                    self.scenes[scene_id][i]['used'] = True
                    sampled_episodes.append(episode)
                    
                if len(sampled_episodes) == 10:
                    break
                
            datasets.append(sampled_episodes)

        return datasets
        
    def create_dataset_for_user_pattern(self, scene_id: str, datasets: List):
        for i, dataset in enumerate(datasets):
            for j, episode in enumerate(self.scenes[scene_id]):
                if episode['used'] == False:
                    datasets[i].append(episode)
                    self.scenes[scene_id][j]['used'] = True

                if len(datasets[i]) == 10:
                    break
        
        return datasets
    
    def extract_categories_from_episode(self, episode):
        evals = episode['evaluation_propositions']
        used_categories = []
            
        for eval in evals:
            used_categories.extend(check_used_object(eval, self.object_category_df, ['clean_category']))
        
        return used_categories
        

    def sample_distractors(self):
        for scene_id, datasets in self.final_dataset.items():
            for dataset in datasets:
                self.sample_distractors_per_dataset(dataset)    
            
    def sample_distractors_per_dataset(self, dataset):
        object_infos = []
        for i, episode in enumerate(dataset):
            # 앞의 5개가 object_semantics
            if i == 5:
                break
            evals = episode['evaluation_propositions']
            for eval in evals:
                object_infos.extend(check_used_object(eval, self.category_cluster_df, ['category', 'cluster']))
        
        
        counter = Counter(map(tuple, object_infos))
        object_infos = [list(k) for k, v in counter.items() if v == 1]
        distractors = []
        
        for category, cluster in object_infos:
            # 같은 category, 다른 cluster sampling
            filtered_df = category_cluster_df[(category_cluster_df['category'] == category) & 
                                                (category_cluster_df['cluster'] != cluster)]  
    
            # 랜덤 샘플링 (해당 데이터가 있을 경우에만)
            if not filtered_df.empty:
                random_row = filtered_df.sample(n=1, random_state=42)  # 랜덤 샘플링
                distractors.append(random_row.iloc[0].to_dict())  # 결과 저장
        
        return distractors
            
    def mid_process(self):
        self.final_dataset = [extract_original_info(ep) for ep in self.final_dataset]
        
        updated_final_dataset = {}
        global_idx = 0
        for scene_id, datasets in self.final_dataset.items():
            updated_datasets = []
            for dataset in datasets:
                updated_datasets.append(renew_episode_info(dataset, global_idx))
                global_idx += len(dataset)  # 사용된 episode 개수만큼 global index 증가
    
            updated_final_dataset[scene_id] = updated_datasets
        self.final_dataset = updated_final_dataset
        
        self.final_dataset = [add_metadata(ep) for ep in self.final_dataset]
        self.final_dataset = [add_stage_2(ep) for ep in self.final_dataset]
    
    def change_hanel(self):
        

    def run(self) -> List[Dict]:
        """
        run the pipeline
        :return: final dataset
        """
        # print("1. Grouping by scene...")
        # scenes = self.group_by_scene()
        # print(f" {len(scenes)} scenes")

        print("2. Sampling episodes per scene")
        print("2-1. Object semantics")
        print("2-2. User pattern")
        self.create_dataset() # self.final_dataset
        
        print("3. add metadata, original_info, process...")
        self.mid_process() # self.final_dataset

        print("sample distractors")
        self.sample_distractors() 
        # 이 이후 distractors 별로 sample을 뽑아 반영하는 로직 필요함
        
        
        print("update instruction")
        # self.update_instructions()
        
        # df_tuple = self.preprocess_instruction_set()
        
        # print("🔹 Tuned Instruction과 Original File을 결합하여 Dataset 생성 중...")
        # self.create_dataset(scenes, df_tuple)
        # print(f" 총 {len(self.final_dataset)}개의 데이터 항목 생성 완료")

        return self.final_dataset


def load_json(file_path: str) -> List[Dict]:
    with open(file_path, "r") as file:
        dataset = json.load(file)
    return dataset

def load_csv(file_path: str) -> pd.DataFrame:
    df = pd.read_csv(file_path)
    return df

def df_to_dict(df: pd.DataFrame, key: str) -> Dict:
    dict_file = df.groupby(key).apply(lambda x: x.drop(columns=[key]).to_dict(orient='records')).to_dict()
    return dict_file

if __name__ == "__main__":
    # raw dataset
    dataset_path = "/HabitatLLM/data/datasets/partnr_episodes/v0_0/val.json"
    dataset: list[Dict] = load_json(dataset_path)['episodes']
    
    category_cluster_df: pd.DataFrame = load_csv("/HabitatLLM/data/hssd-hab/metadata/category_cluster.csv")
    
    # tuned instructions
    object_path = "/HabitatLLM/data/instructions/seperate/object.json"
    instruction_object: list[Dict] = load_json(object_path)
    preference_path = "/HabitatLLM/data/instructions/seperate/preference.json"
    instruction_preference: list[Dict] = load_json(preference_path)
    routine_path = "/HabitatLLM/data/instructions/seperate/routine.json"
    instruction_routine: list[Dict] = load_json(routine_path)

    instructions = {
        "object": instruction_object,
        "preference": instruction_preference,
        "routine": instruction_routine
    }

    # object categories
    obj_category_file = "/HabitatLLM/data/hssd-hab/metadata/object_categories_filtered.csv"
    obj_category_df = pd.read_csv(obj_category_file)

    # 더미 샘플링 함수 정의 (실제 구현 시 더 복잡한 로직 필요)
    def dummy_distractor_sampling(data):
        data["augmented"] = True
        return data

    pipeline = TaskPipeline(data_path = dataset_path,
                            tuned_instructions = instructions,
                            dataset = dataset, 
                            distractor_sampling_fn = dummy_distractor_sampling,
                            object_category_df = obj_category_df,
                            category_cluster_df = category_cluster_df)
    
    final_dataset = pipeline.run()

    output_path = "/HabitatLLM/preprocess/final_dataset.json"
    
    with open(output_path, "w") as output_file:
        json.dump(final_dataset, output_file, indent=4)

    
    print(f"saved on {output_path}")
    # print(json.dumps(final_dataset, indent=4))