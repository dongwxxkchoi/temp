import json
from copy import deepcopy

def output_as_dataset(episodes: list, output_path: str):
    dataset = {
        "config": None,
        "episodes": episodes
    }
    
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(dataset, f, indent=4, ensure_ascii=False)
    
    print(f"Dataset saved to {output_path}")


def extract_original_info(episodes: list, data_path: str):
    # 1. original info 더하기
    for i, episode in enumerate(episodes):
        episode_id = episode['episode_id']
        instruction = episode['instruction']
        data_path = data_path
        episodes[i]['original_data_info'] = {
            "episode_id": episode_id, 
            "instruction": instruction, 
            "data_path": data_path
        }
    
    return episodes


def renew_episode_info(episodes: list, start_idx: int):
    # 2. info 더하기
    for i, episode in enumerate(episodes):
        episodes[i]['episode_id'] = str(start_idx + i)
    
    return episodes
        
    

def add_metadata(episodes: list):
    # 3. metadata 더하기
    for i, episode in enumerate(episodes):
        stage = 1
        related_episode_id = str(int(episode['episode_id']) + 1000)
        episodes[i]['metadata'] = {
            'stage': "1",
            'related_episode_id': related_episode_id
        }
    
    return episodes
    
    
    # - meta_data:
    #     - stage: (1 or 2)
    #     - related_episode_id: (연결된 episode_id)
    # - original_data_info:
    #     - episode_id
    #     - instruction
    #     - data_path


def add_stage_2(episodes: list):
    stage_2 = []
    
    for episode in episodes:
        new_episode = deepcopy(episode) 
        new_episode['metadata'] = {
            'stage': "2",
            'related_episode_id': str(episode['episode_id'])
        }
        new_episode['episode_id'] = str(int(episode['episode_id']) + 1000)
        stage_2.append(new_episode)
    
    episodes.extend(stage_2)
    
    return episodes
    
    