import json
from collections import defaultdict
from typing import List, Dict, Callable
import random

import pandas as pd

class TaskPipeline:
    def __init__(self, 
                 tuned_instructions: List[Dict], 
                 dataset: Dict, 
                 distractor_sampling_fn: Callable, 
                 object_category_count: pd.Series
                 ):  
        """
        :param dataset: 원본 instruction 파일 리스트 (List of Dict)
        :param tuned_instructions: 튜닝된 instruction 리스트 (List of Dict)
        :param distractor_sampling_fn: 데이터 샘플링 함수
        """
        self.tuned_instructions = tuned_instructions
        self.dataset = dataset
        self.distractor_sampling_fn = distractor_sampling_fn
        self.final_dataset = None

    def group_by_scene(self) -> Dict[str, List[Dict]]:
        """
        Scene ID 기준으로 에피소드 그룹화
        :return: scene_id를 key로 하는 episode dictionary
        """
        scene_dict = defaultdict(list)
        for episode in self.dataset:
            scene_id = episode.get("scene_id", "unknown_scene")
            scene_dict[scene_id].append(episode)
        return scene_dict

    def preprocess_instruction_set(self):
        """
        Instruction set을 전처리하여 적절한 형태로 변환
        """
        object_df = pd.DataFrame(self.tuned_instructions["object"])
        routine_df = pd.DataFrame(self.tuned_instructions["routine"])
        preference_df = pd.DataFrame(self.tuned_instructions["preference"])

        return object_df, routine_df, preference_df


    def create_dataset(self, scenes, df_tuple) -> List[Dict]:
        """
        Tuned instruction과 Original file을 결합하여 새로운 dataset 생성
        :return: 결합된 dataset 리스트
        """
        import copy

        object_df, routine_df, preference_df = df_tuple
        object_k = 2
        routine_k = 1
        preference_k = 1

        self.final_dataset = {}

        for scene_id, episodes in scenes.items():
            random_episodes = random.sample(episodes, object_k+routine_k+preference_k)
            random.shuffle(random_episodes)

            object_episodes = random_episodes[:object_k]
            routine_episodes = random_episodes[object_k:object_k+routine_k]
            preference_episodes = random_episodes[object_k+routine_k:object_k+routine_k+preference_k]

            samples = []

            for ep in object_episodes:
                sample = object_df[(object_df['episode_id'] == ep['episode_id']) & (object_df['scene_id'] == ep['scene_id'])]['step_1_output']
                new_ep = copy.deepcopy(ep)
                new_ep.update({"new_instruction": sample.iloc[0], "stage": "mem"})
                samples.append(new_ep)

            for ep in routine_episodes:
                sample = routine_df[(routine_df['episode_id'] == ep['episode_id']) & (routine_df['scene_id'] == ep['scene_id'])]['step_1_output']
                new_ep = copy.deepcopy(ep)
                new_ep.update({"new_instruction": sample.iloc[0], "stage": "mem"})
                samples.append(new_ep)

            for ep in preference_episodes:
                sample = preference_df[(preference_df['episode_id'] == ep['episode_id']) & (preference_df['scene_id'] == ep['scene_id'])]['step_1_output']
                new_ep = copy.deepcopy(ep)
                new_ep.update({"new_instruction": sample.iloc[0], "stage": "mem"})
                samples.append(new_ep)

            for ep in object_episodes:
                sample = object_df[(object_df['episode_id'] == ep['episode_id']) & (object_df['scene_id'] == ep['scene_id'])]['step_2_output']
                new_ep = copy.deepcopy(ep)
                new_ep.update({"new_instruction": sample.iloc[0], "stage": "eval"})
                samples.append(new_ep)

            for ep in routine_episodes:
                sample = routine_df[(routine_df['episode_id'] == ep['episode_id']) & (routine_df['scene_id'] == ep['scene_id'])]['step_2_output']
                new_ep = copy.deepcopy(ep)
                new_ep.update({"new_instruction": sample.iloc[0], "stage": "eval"})
                samples.append(new_ep)

            for ep in preference_episodes:
                sample = preference_df[(preference_df['episode_id'] == ep['episode_id']) & (preference_df['scene_id'] == ep['scene_id'])]['step_2_output']
                new_ep = copy.deepcopy(ep)
                new_ep.update({"new_instruction": sample.iloc[0], "stage": "eval"})
                samples.append(new_ep)

            self.final_dataset[scene_id] = samples
            
            break

        return self.final_dataset

    def apply_sampling_function(self):
        """
        샘플링 함수를 사용하여 데이터 증강 수행
        """
        if self.dataset is None:
            raise ValueError("Dataset is not initialized. Run `create_dataset` first.")
        
        augmented_dataset = [self.distractor_sampling_fn(data) for data in self.dataset]
        self.final_dataset = augmented_dataset

    def run(self) -> List[Dict]:
        """
        전체 파이프라인 실행
        :return: 최종 데이터셋 (샘플링까지 완료된 데이터)
        """
        print("🔹 Scene별로 데이터 분류 중...")
        scenes = self.group_by_scene()
        print(f"✅ {len(scenes)}개의 Scene을 분류 완료!")

        df_tuple = self.preprocess_instruction_set()
        
        print("🔹 Tuned Instruction과 Original File을 결합하여 Dataset 생성 중...")
        self.create_dataset(scenes, df_tuple)
        print(f"✅ 총 {len(self.final_dataset)}개의 데이터 항목 생성 완료!")

        # print("🔹 Distractor Sampling Function 적용 중...")
        # self.apply_sampling_function()
        # print(f"✅ 샘플링 적용 완료!")

        return self.final_dataset


def load_dataset(file_path: str) -> List[Dict]:
    """
    데이터셋을 JSON 파일에서 로드
    :param file_path: 파일 경로
    :return: 로드된 데이터셋
    """
    with open(file_path, "r") as file:
        dataset = json.load(file)
    return dataset

# 예제 실행
if __name__ == "__main__":
    # 예제 데이터 로드 (실제 사용 시 JSON 파일에서 로드 가능)
    dataset_path = "/HabitatLLM/data/datasets/partnr_episodes/v0_0/val.json"
    dataset: list[Dict] = load_dataset(dataset_path)['episodes']
    
    object_path = "/HabitatLLM/data/instructions/seperate/object.json"
    instruction_object: list[Dict] = load_dataset(object_path)
    preference_path = "/HabitatLLM/data/instructions/seperate/preference.json"
    instruction_preference: list[Dict] = load_dataset(preference_path)
    routine_path = "/HabitatLLM/data/instructions/seperate/routine.json"
    instruction_routine: list[Dict] = load_dataset(routine_path)

    instructions = {
        "object": instruction_object,
        "preference": instruction_preference,
        "routine": instruction_routine
    }

    obj_category_file = "/HabitatLLM/data/hssd-hab/metadata/object_categories_filtered.csv"
    obj_category_df = pd.read_csv(obj_category_file)
    obj_category_count = obj_category_df['clean_category'].value_counts()
    obj_category_count = obj_category_count[obj_category_count > 1]

    # 더미 샘플링 함수 정의 (실제 구현 시 더 복잡한 로직 필요)
    def dummy_distractor_sampling(data):
        data["augmented"] = True
        return data

    pipeline = TaskPipeline(tuned_instructions = instructions,
                            dataset = dataset, 
                            distractor_sampling_fn = dummy_distractor_sampling,
                            object_category_count = obj_category_count
                            )
    final_dataset = pipeline.run()

    output_path = "/HabitatLLM/preprocess/final_dataset_sample.json"
    
    with open(output_path, "w") as output_file:
        json.dump(final_dataset, output_file, indent=4)
        
    print(f"✅ 최종 데이터셋이 {output_path}에 저장되었습니다.")
    # print(json.dumps(final_dataset, indent=4))