import json
import random
import pandas as pd

with open("/data/hssd-hab/metadata/filtered_captions.json") as f:
    caption_json = json.load(f)

with open("/data/hssd-hab/metadata/category_handle_filtered.json") as f:
    category_img_json = json.load(f)

category_full_df = pd.read_csv("/data/hssd-hab/metadata/object_categories_filtered.csv")

category_cluster_path = "/HabitatLLM/data/hssd-hab/metadata/category_cluster.csv"
category_cluster_df = pd.read_csv(category_cluster_path)

def load_room_objects(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def sample_initial_objects(room_objects, num_samples=10):
    return random.sample(room_objects, num_samples)

def random_divide(episodes: list):
    if len(episodes) != 10:
        raise ValueError("episodes 리스트는 정확히 10개의 요소를 가져야 합니다.")
    
    random.shuffle(episodes)
    return [episodes[:5], episodes[5:]] # object semantics / user pattern

def process_object_episodes(episodes: list):
    categories = []
    for episode in episodes:
        for eval in episode['evaluation_propositions']:
            logs: dict = check_eval_object(eval['object_handles']) # {old: new}


def check_eval_object(evaluations: list):
    """
    evaluation 별로 필요한 object 얻기 위해
    ['is_inside', 'is_in_room', 'is_on_floor', 'is_next_to', 'is_on_top', 
    'is_filled', 'is_powered_off', 'is_clean', 'is_powered_on']
    Args:
        evaluations (list): episode['evaluation prposition']
    """
    logs = {}
    
    for eval in evaluations:
        if eval['function_name'] in ["is_on_top", "is_inside", "is_in_room", "is_on_floor"]:
            objects = eval['args']['object_handles']
            for object in objects:
                if not check_if_handle_has_image(object):
                    new_object = random_sample_from_category(object)
                    logs[object] = new_object
                #TODO: 반영?
        elif eval['function_name'] == "is_next_to": # object_handle_a, object_handle_b
            objects_a = eval['args']['entity_handles_a']
            objects_b = eval['args']['entity_handles_b']
            for object in objects_a:
                if not check_if_handle_has_image(object):
                    new_object = random_sample_from_category(object)
                    logs[object] = new_object
            for object in objects_b:
                if not check_if_handle_has_image(object):
                    new_object = random_sample_from_category(object)
                    logs[object] = new_object
                    
    return logs
            

def check_if_handle_has_image(handle: str):
    handle_name = handle.split(":")[0][:-1] # {handle}_:0000
    if caption_json.get(handle_name, None):
        return True
    else:
        return False


def random_sample_from_category(handle: str):
    handle_name = handle.split(":")[0][:-1] # {handle}_:0000
    category = category_full_df[category_full_df['id'] == handle_name]['clean_category'].values[0]
    new_handle = random.sample(category_img_json[category], 1)[0]['id']
    return new_handle


def find_alternative(obj, room_objects):
    category = obj["category"]
    alternatives = [o for o in room_objects if o["category"] == category and o != obj]
    if alternatives:
        return random.choice(alternatives)
    
    # If no alternative in same category, find another category with at least 2 items
    multi_category_objs = {}
    for o in room_objects:
        multi_category_objs.setdefault(o["category"], []).append(o)
    
    possible_categories = [cat for cat, objs in multi_category_objs.items() if len(objs) >= 2]
    if not possible_categories:
        return obj  # No alternative found, return original
    
    new_category = random.choice(possible_categories)
    return random.choice(multi_category_objs[new_category])

def check_category_existence(obj, used_categories, room_objects):
    if obj["category"] in used_categories:
        return find_alternative(obj, room_objects)
    return obj

def is_distractor_sampling_possible(obj):
    # Placeholder for captioning grouping logic
    return True

def process_objects(episodes: list, room_objects, num_user_pattern=5, num_object_semantics=5):
    #selected_objects = sample_initial_objects(room_objects, num_user_pattern + num_object_semantics)
    #10개 episodes
    
    object_episodes, user_episodes = random_divide(episodes)
    
    processed_object_episodes = process_object_episodes(object_episodes)
    user_pattern_objects = selected_objects[:num_user_pattern]
    object_semantics_objects = selected_objects[num_user_pattern:]
    
    used_categories = set()
    processed_objects = []
    
    for obj in object_semantics_objects:
        if not has_handle_image(obj):
            obj = find_alternative(obj, room_objects)
        
        obj = check_category_existence(obj, used_categories, room_objects)
        
        if not is_distractor_sampling_possible(obj):
            obj = find_alternative(obj, room_objects)
        
        used_categories.add(obj["category"])
        processed_objects.append(obj)
    
    return user_pattern_objects, processed_objects

# Example Usage
room_objects = load_room_objects("room_objects.json")
user_pattern_objects, processed_objects = process_objects(room_objects)

print("User Pattern Objects:", user_pattern_objects)
print("Object Semantics Objects:", processed_objects)