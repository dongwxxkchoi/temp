## METADATA -> metadata_interface에서 다룸
  
### object 중 state 부여 가능한 것들 (ex. clean)
- /HabitatLLM/data/hssd-hab/metadata/affordance_objects.csv  

### object 중 어떤 room에 주로 있는지 관련한 것들
- /HabitatLLM/data/hssd-hab/metadata/room_objects.json  

### (handle, category) mapping 내역 => 이게 perception에 적극 활용됨
- /HabitatLLM/data/hssd-hab/metadata/object_categories_filtered.csv  

### captions
- object_captions_source.json  
source를 키로 list로 정리함  
- object_captions_handle.json  
handle을 키로    
- filtered_captions.json  
category가 2개 이상인 objects만 남김   